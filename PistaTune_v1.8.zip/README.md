# PistaTune v1.8 — rebranding de EasyTune v1.7

**La calculadora no cambió.** Este paquete conserva los siete modos, el catálogo y búsqueda de autos, la sugerencia de piezas (sin precios), el comparador de relaciones de marcha, las pruebas reales opcionales, las configuraciones guardadas y su exportación, con una nueva marca visible y metadatos para buscadores.

## Publicar / actualizar en GitHub Pages

1. Subí o reemplazá **solo `index.html`** en la raíz del repositorio y confirmá el commit.
2. Podés dejar el repositorio llamado `easytune` inicialmente: la página ya se verá como **PistaTune**. Así no cambia la dirección de tu página hasta que decidas actualizarla.
3. Si querés cambiar también la dirección a `/pistatune/`, entrá a **Settings → General → Repository name** y cambiá `easytune` por `pistatune`. Revisá **Settings → Pages** después y actualizá todos los enlaces que hayas compartido. La URL vieja de GitHub Pages no tiene redirección garantizada.
4. Para aparecer en Google, publicá el sitio, verificá la URL real en [Google Search Console](https://search.google.com/search-console) y solicitá su indexación. Estar indexado no garantiza aparecer primero.

## Compatibilidad y límites

- Conservar las claves antiguas de `localStorage` es **deliberado**: los tuneos, pruebas y piezas guardadas con EasyTune deberían seguir siendo accesibles si publicás en el mismo dominio/origen de GitHub Pages. Si cambiás a un dominio distinto o abrís como `file://`, el navegador puede separar los datos; **exportá antes una copia JSON** desde «Mis guardados».
- Para mantener la compatibilidad externa, el formato de exportación JSON interno sigue siendo `easytune-v1` aunque el nombre del archivo exportado será `pistatune-guardados.json`.
- Las recomendaciones siguen siendo **estimaciones**, no las mejores configuraciones medidas de Forza.
- No se introdujeron precios de piezas.
- El nombre está **pendiente de verificación marcaria completa** y de disponibilidad del dominio deseado. Las búsquedas generales no sustituyen el buscador oficial del INPI.
- Aplicación independiente y no afiliada a Forza o Xbox.
