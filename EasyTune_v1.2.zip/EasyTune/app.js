/* EasyTune — interfaz en español, sin frameworks ni servicios externos. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const CARS = window.EASYTUNE_CARS || [];
  const ENGINE = window.EasyTuneEngine;
  const CATALOG = window.EasyTuneCatalog;
  if(!ENGINE) { document.body.insertAdjacentHTML('afterbegin', '<div class="no-js">No se pudo cargar el motor local.</div>'); return; }
  const MODE_ORDER = ['balance','accel','speed','grip','technical','drift','offroad'];
  const FEATURED_CAR = CARS.find(c => c.make === 'Lamborghini' && c.model === 'Sesto Elemento') || CARS[0];
  const ADVANCED_FIELDS=['power','mass','front','rpm','radius','tire','hasSusp','hasAero','hasBrakes','hasDiff',
    'springFMin','springFMax','springRMin','springRMax','heightFMin','heightFMax','heightRMin','heightRMax'];
  let selectedCar=FEATURED_CAR||null, manual=false, activeStep=1, selectedMode='balance', tune=null, allOpen=false, toastTimeout=null;
  let saved=readSaved();
  const format=(x,d=0) => typeof x==='number' ? x.toLocaleString('es-AR',{minimumFractionDigits:d,maximumFractionDigits:d}) : String(x);
  const number=(x,d=0)=>format(x,d);
  const safe=x=>String(x).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const escapeAttr=safe;
  const normalize=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  function readSaved() {try{const x=JSON.parse(localStorage.getItem('easytune.saves.v1')||'[]');return Array.isArray(x)?x.slice(0,50):[]}catch{return []}}
  function writeSaved(){try{localStorage.setItem('easytune.saves.v1',JSON.stringify(saved));}catch{toast('El navegador no pudo guardar los datos.')} updateSavedCount();}
  function updateSavedCount(){$('savedCount').hidden=saved.length===0; $('savedCount').textContent=saved.length;}
  function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>el.classList.remove('show'),2900);}
  function applyCar(car){
    selectedCar=car;manual=false;
    $('carSearch').value=car.label;
    $('clearSearch').hidden=false;
    $('searchFeedback').hidden=true;
    $('selectedCar').hidden=false;
    $('manualCarPanel').hidden=true;
    $('manualSwitch').textContent='+ Agregar un auto que no aparece';
    $('drive').value=car.drive;
    $('gears').value=String(car.gears);
    // Borramos los datos específicos anteriores para evitar confundir dos autos.
    ['power','mass','front','rpm','radius','springFMin','springFMax','springRMin','springRMax','heightFMin','heightFMax','heightRMin','heightRMax'].forEach(id=>$(id).value='');
    $('tire').value='sport';
    $('selectedCarTitle').textContent=car.make+' '+car.model;
    $('selectedCarMeta').textContent=car.year+' · '+car.category+' · '+car.pi;
    $('carAssumptions').hidden=!car.isEstimatedDrivetrain;
    const mark=$('selectedCar').querySelector('.verified-label');
    if(mark){mark.textContent=car.catalogSource==='comunitario'?'Lista comunitaria':'✓ Catálogo';mark.title=car.catalogSource==='comunitario'?'Datos de una lista comunitaria; verificá en el juego':'Modelo y clase del catálogo; datos mecánicos estimados';}
    closeSearch();refreshSide();
  }
  function switchManual(name){
    selectedCar=null;manual=true;
    $('selectedCar').hidden=true;
    $('carSearch').value=(name || '').trim();
    $('clearSearch').hidden=!$('carSearch').value;
    $('searchFeedback').hidden=true;
    $('manualCarPanel').hidden=false;
    $('carAssumptions').hidden=true;
    $('manualSwitch').textContent='← Volver a elegir un auto del catálogo';
    $('customName').value=(name || '').trim();
    $('drive').value='RWD';$('gears').value='6';
    ['power','mass','front','rpm','radius','springFMin','springFMax','springRMin','springRMax','heightFMin','heightFMax','heightRMin','heightRMax'].forEach(id=>$(id).value='');
    closeSearch();refreshSide();
  }
  function toggleManual(){if(manual){applyCar(FEATURED_CAR);$('carSearch').focus();}else{switchManual($('carSearch').value===selectedCar?.label?'':$('carSearch').value);$('customName').focus();}}
  function closeSearch(){$('carOptions').hidden=true;$('carSearch').setAttribute('aria-expanded','false');}
  function showMatches(value){
    const list=$('carOptions');
    const typed=value.trim();const term=normalize(typed);
    const pending=!!typed && (!selectedCar || value!==selectedCar.label);
    $('selectedCar').hidden=pending || !typed || manual;
    const feedback=$('searchFeedback');
    feedback.hidden=!pending;
    if(!pending){closeSearch();refreshSide();return;}
    const matches=CARS.filter(c => {
      const tokens=[`${c.make} ${c.model}`,`${c.make} ${c.model} ${c.year}`,`${c.year} ${c.make} ${c.model}`,c.label];
      return tokens.some(t=>normalize(t).includes(term));
    }).sort((a,b)=> {
      const rank=c=> {
        const model=normalize(c.model),brand=normalize(c.make),full=brand+' '+model;
        if(model===term||full===term)return 0;
        if(model.startsWith(term))return 1;
        if(full.startsWith(term))return 2;
        if(brand===term)return 3;
        return 4;
      };
      return rank(a)-rank(b)||a.model.localeCompare(b.model,'es')||a.year-b.year;
    }).slice(0,10);
    const resultRows=matches.map(c=>`<button type="button" class="option-row" data-car-id="${c.id}" role="option"><span>${safe(c.make+' '+c.model)} <small>· ${c.year}</small></span><small>${safe(c.pi)}</small></button>`).join('');
    const customRow=`<button type="button" class="option-row option-row--custom" id="useCustomFromSearch"><span>＋ Usar <strong>«${safe(typed)}»</strong> como auto personalizado</span><span aria-hidden="true">→</span></button>`;
    list.innerHTML=resultRows+customRow;
    feedback.textContent=matches.length?'Elegí un modelo de la lista. Si no es ninguno, podés usar el nombre escrito.':'No aparece entre los autos precargados. Podés continuar igual con este nombre.';
    list.hidden=false;$('carSearch').setAttribute('aria-expanded','true');refreshSide();
  }
  function renderModes(){
    $('modeGrid').innerHTML=MODE_ORDER.map(id=>{
      const m=ENGINE.MODES[id];const chosen=id===selectedMode;
      return `<button type="button" role="radio" aria-checked="${chosen}" class="mode-card ${chosen?'selected':''}" data-mode="${id}"><span class="mode-emoji" aria-hidden="true">${m.emoji}</span><span class="mode-card-content"><strong>${m.label}</strong><small>${m.description}</small></span><span class="mode-select" aria-hidden="true">${chosen?'●':'○'}</span></button>`;
    }).join('');
    refreshSide();
  }
  function refreshSide(){
    const typed=$('carSearch').value.trim();
    const pending=!manual && (!selectedCar || typed!==selectedCar.label);
    const name=manual?($('customName').value.trim()||'Auto personalizado') : pending?(typed||'Elegí tu auto') : (selectedCar.make+' '+selectedCar.model);
    $('sideCarName').textContent=name;
    $('sideCarMeta').textContent=manual?'Datos personalizados (estimados)':pending?'Seleccioná un resultado o continuá con tu nombre':selectedCar.year+' · '+selectedCar.pi;
    const m=ENGINE.MODES[selectedMode];$('sideModeIcon').textContent=m.emoji;$('sideModeName').textContent=m.label;
    $('sideModeDesc').textContent=m.description;
  }
  function goStep(n){
    if(n===2 && !validateCar())return;
    if(n===3){if(!validateCar())return;computeAndRender();}
    activeStep=n;
    [1,2,3].forEach(i=>{
      $('step'+i).hidden=i!==n;
      const nav=$('nav'+i);nav.classList.toggle('active',i===n);nav.classList.toggle('complete',i<n);
      nav.setAttribute('aria-current',i===n?'step':'false');
    });
    window.scrollTo({top:Math.max(0,document.querySelector('.steps').getBoundingClientRect().top+scrollY-20),behavior:'smooth'});
  }
  function validateCar(){
    if(!manual && selectedCar && $('carSearch').value===selectedCar.label)return true;
    const term=$('carSearch').value.trim();
    if(!manual && term.length>=2){switchManual(term);return true;}
    if(manual && $('customName').value.trim().length>=2)return true;
    toast('Escribí o elegí un auto para continuar.');return false;
  }
  function readInput(){
    const field=id=>$(id).value.trim();
    const ranges={};
    ['springFMin','springFMax','springRMin','springRMax','heightFMin','heightFMax','heightRMin','heightRMax'].forEach(x=>ranges[x]=field(x));
    return {
      car:manual?null:selectedCar,
      name:manual?field('customName') : selectedCar.label,
      profile:manual?$('customProfile').value:selectedCar.profile,
      drive:$('drive').value,gears:field('gears'),power:field('power'),mass:field('mass'),front:field('front'),rpm:field('rpm'),radius:field('radius'),
      tire:$('tire').value,
      adjustables:{suspension:$('hasSusp').checked,aero:$('hasAero').checked,brakes:$('hasBrakes').checked,diff:$('hasDiff').checked},
      ranges,mode:selectedMode,bias:Number($('bias').value)
    };
  }
  function showBias(){const v=Number($('bias').value);$('biasValue').textContent=v===0?'Equilibrado':v<0?`Más estable (${Math.abs(v)})`:`Más ágil (${v})`;}
  function computeAndRender(){
    try{tune=ENGINE.calculate(readInput());renderResults();}
    catch(e){console.error(e);toast('No pudimos calcular los ajustes. Revisá los números.');}
  }
  const row=(label,value,unit='',relative=false,disabled=false)=>({label,value,unit,relative,disabled});
  function buildSections(t){
    const s=t.specs;const u=s.adjustables;const p=t.springs;
    const lockedRow=txt=>[row('Este apartado',txt,'',true,true)];
    const springsNote='Los valores en % son una posición aproximada del deslizador, porque los límites dependen de cada pieza. Podés ingresar mínimos y máximos en el paso 1 para obtener kgf/mm y cm.';
    return [
      {name:'Neumáticos',blurb:'Presión de las ruedas',rows:[row('Delanteros',number(t.tires.front,2),'bares'),row('Traseros',number(t.tires.rear,2),'bares')],hint:'Presión inicial estimada. Probá cambios pequeños y controlá la temperatura y el agarre.'},
      {name:'Relaciones de marchas',blurb:'Aceleración y velocidad',rows:[row('Transmisión final',number(t.transmission.final,2)),...t.transmission.ratios.map((v,i)=>row(`${i+1}ª marcha`,number(v,2)))],hint:`Límite teórico por RPM en última marcha: ${format(t.transmission.topSpeedRpm)} km/h. No es la velocidad punta real; no contempla resistencia del aire, potencia ni pérdida de tracción. Si el motor toca el limitador antes de lo deseado, alargá la relación final (número más bajo).`},
      {name:'Alineación',blurb:'Cómo apoyan las ruedas',rows:[row('Caída delantera',number(t.align.camF,1),'°'),row('Caída trasera',number(t.align.camR,1),'°'),row('Convergencia delantera',number(t.align.toeF,1),'°'),row('Convergencia trasera',number(t.align.toeR,1),'°'),row('Avance',number(t.align.caster,1),'°')],hint:'La caída negativa ayuda a apoyar en curvas, pero demasiada perjudica la frenada. Empezá con convergencia cercana a cero.'},
      {name:'Barras estabilizadoras',blurb:'Cuánto se inclina al doblar',rows:u.suspension?[row('Delantera',number(t.bars.front,1)),row('Trasera',number(t.bars.rear,1))]:lockedRow('Requiere piezas regulables'),hint:'Un cambio de barras modifica el equilibrio en curva. Si el auto no gira, probá un poco menos adelante o más atrás.'},
      {name:'Muelles y altura',blurb:'Dureza y distancia al suelo',rows:u.suspension?[row('Muelle delantero',typeof p.front.value==='number'?number(p.front.value,1):p.front.value,p.front.unit,typeof p.front.value!=='number'),row('Muelle trasero',typeof p.rear.value==='number'?number(p.rear.value,1):p.rear.value,p.rear.unit,typeof p.rear.value!=='number'),row('Altura delantera',typeof p.heightF.value==='number'?number(p.heightF.value,1):p.heightF.value,p.heightF.unit,typeof p.heightF.value!=='number'),row('Altura trasera',typeof p.heightR.value==='number'?number(p.heightR.value,1):p.heightR.value,p.heightR.unit,typeof p.heightR.value!=='number')]:lockedRow('Requiere suspensión regulable'),hint:springsNote},
      {name:'Amortiguación',blurb:'Control de rebotes',rows:u.suspension?[row('Rebote delantero',number(t.damping.reboundF,1)),row('Rebote trasero',number(t.damping.reboundR,1)),row('Compresión delantera',number(t.damping.bumpF,1)),row('Compresión trasera',number(t.damping.bumpR,1))]:lockedRow('Requiere suspensión regulable'),hint:'El rebote controla la extensión y la compresión controla cómo absorbe un bache. Son sugerencias aproximadas para empezar.'},
      {name:'Aerodinámica',blurb:'Agarre a alta velocidad',rows:u.aero?[row('Carga delantera',t.aero.front,'',true),row('Carga trasera',t.aero.rear,'',true)]:lockedRow('No tenés aero regulable'),hint:u.aero?'Se indica % del deslizador porque la carga máxima cambia entre kits y autos. Mayor carga suele mejorar curvas rápidas, a costa de la velocidad punta.':'Si instalás alerón o divisor delantero regulable, marcá la opción en el paso 1.'},
      {name:'Frenos',blurb:'Estabilidad al frenar',rows:u.brakes?[row('Equilibrio',number(t.brakes.balance),'% delante'),row('Presión',number(t.brakes.pressure),'%')]:lockedRow('Requiere frenos regulables'),hint:'El equilibrio indica la proporción de frenado delantero. Si bloqueás ruedas o perdés estabilidad, ajustá gradualmente.'},
      {name:'Diferencial',blurb:'Cómo llega la potencia a las ruedas',rows:u.diff ? s.drive==='AWD' ?[
        row('Delantero aceleración',number(t.diff.fAccel),'%'),row('Delantero desaceleración',number(t.diff.fDecel),'%'),
        row('Trasero aceleración',number(t.diff.rAccel),'%'),row('Trasero desaceleración',number(t.diff.rDecel),'%'),row('Central: torque atrás',number(t.diff.center),'%')
      ]:[row('Aceleración',number(t.diff.accel),'%'),row('Desaceleración',number(t.diff.decel),'%')]:lockedRow('Requiere diferencial regulable'),hint:'Más bloqueo en aceleración puede transmitir mejor la potencia, pero demasiado puede hacer que el auto se resista a girar.'}
    ];
  }
  function renderResults(){
    if(!tune)return;
    const t=tune;
    $('resultFor').textContent=t.specs.carName+' · '+t.mode.label;
    const estimated=t.specs.isPreset;
    $('sourceWarning').textContent=(estimated?'Datos de rendimiento: aproximados por tipo de vehículo (no tomados de la pantalla del juego).':'Se usan los datos que ingresaste; los campos vacíos siguen siendo estimaciones.')+(t.guidance?' '+t.guidance:'');
    const sections=buildSections(t);
    window._easyTuneSections=sections;
    $('resultsList').innerHTML=sections.map((sec,i)=>{
      const open=allOpen||i<2;
      return `<details class="tune-section" data-section="${i}" ${open?'open':''}><summary><span class="result-index">${String(i+1).padStart(2,'0')}</span><span class="result-title"><strong>${safe(sec.name)}</strong><small>${safe(sec.blurb)}</small></span><span class="result-chevron" aria-hidden="true">›</span></summary><div class="result-body"><div class="result-rows">${sec.rows.map(r=>`<div class="tune-row ${r.disabled?'disabled':''}"><span class="r-label">${safe(r.label)}</span><span class="r-value ${r.relative?'relative':''}">${safe(r.value)}${r.unit?`<span class="r-unit">${safe(r.unit)}</span>`:''}</span></div>`).join('')}</div><p class="result-note ${sec.name==='Muelles y altura'?'attention':''}">${safe(sec.hint)}</p><button type="button" class="result-copy" data-copy-section="${i}">▢ Copiar esta sección</button></div></details>`;
    }).join('');
    $('toggleAll').textContent=allOpen?'Cerrar todas':'Abrir todas';
  }
  function sectionText(sec){return `${sec.name}\n`+sec.rows.map(r=>`  ${r.label}: ${r.value}${r.unit?' '+r.unit:''}`).join('\n')+'\n';}
  function fullText(){
    if(!tune)return '';
    return `EASYTUNE — CONFIGURACIÓN ESTIMADA, NO OPTIMIZADA EN PISTA\n${tune.specs.carName}\nModo: ${tune.mode.label}\nTracción: ${tune.specs.drive} · ${tune.specs.gears} marchas\n\n${buildSections(tune).map(sectionText).join('\n')}\nFuente catálogo: https://forza.net/fh6cars\nAviso: números orientativos sin validación de telemetría.\n`;
  }
  function copyText(txt){
    if(navigator.clipboard?.writeText){navigator.clipboard.writeText(txt).then(()=>toast('¡Copiado! Pegalo donde quieras.')).catch(()=>legacyCopy(txt));}
    else legacyCopy(txt);
  }
  function legacyCopy(str){
    const textarea=document.createElement('textarea'); textarea.value=str;textarea.style.cssText='position:fixed;left:-9999px;top:0';document.body.appendChild(textarea);
    textarea.focus();textarea.select();let ok=false;try{ok=document.execCommand('copy')}catch{}textarea.remove();
    toast(ok?'¡Copiado!':'No se pudo copiar: probá descargar el TXT.');
  }
  function download(name,contents,type){
    const blob=new Blob([contents],{type});const href=URL.createObjectURL(blob);const a=document.createElement('a');
    a.href=href;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(href),1000);
  }
  function saveCurrent(){
    if(!tune)return;
    const carname=tune.specs.carName;
    const label=`${carname} · ${tune.mode.label}`;
    const id=(typeof crypto!=='undefined' && crypto.randomUUID)?crypto.randomUUID():String(Date.now())+'-'+Math.floor(Math.random()*99999);
    saved.unshift({id,label,carId:selectedCar?.id||null,manual,name:readInput().name,profile:readInput().profile,mode:selectedMode,bias:Number($('bias').value),input:readInput(),created:Date.now()});
    saved=saved.slice(0,50);writeSaved();toast('Configuración guardada en este navegador.');
  }
  function showSaves(){
    $('savedItems').innerHTML=saved.length ? saved.map(s=>`<div class="saved-row"><div><strong>${safe(s.label)}</strong><small>${new Date(s.created).toLocaleDateString('es-AR')}</small></div><div class="saved-row-actions"><button type="button" data-load="${escapeAttr(s.id)}">Abrir</button><button type="button" class="delete" data-delete="${escapeAttr(s.id)}" aria-label="Eliminar configuración">✕</button></div></div>`).join('') : '<div class="empty-saves">Todavía no guardaste ninguna. Creá un tuneo y tocá ♡ Guardar.</div>';
    $('savesDialog').showModal();
  }
  function loadSave(s){
    selectedMode=ENGINE.MODES[s.mode]?s.mode:'balance';
    const car=CARS.find(c=>c.id===s.carId);
    if(car)applyCar(car);else{switchManual(s.name);$('customProfile').value=s.profile||'sport';}
    const inp=s.input||{};
    $('drive').value=inp.drive||'RWD';$('gears').value=String(inp.gears||6);
    ['power','mass','front','rpm','radius','tire'].forEach(id=>{if(inp[id]!==undefined)$(id).value=inp[id];});
    $('hasSusp').checked=inp.adjustables?.suspension!==false;
    $('hasAero').checked=!!inp.adjustables?.aero;
    $('hasBrakes').checked=inp.adjustables?.brakes!==false;
    $('hasDiff').checked=inp.adjustables?.diff!==false;
    Object.keys(inp.ranges||{}).forEach(id=>{if($(id))$(id).value=inp.ranges[id];});
    $('bias').value=String(s.bias||0);showBias();renderModes();
    $('savesDialog').close();goStep(3);toast('Configuración recuperada.');
  }
  function setCatalogStatus(message, ready=false){
    $('catalogCount').textContent=CARS.length.toLocaleString('es-AR');
    $('catalogStatus').textContent=message;
    $('catalogHint').classList.toggle('ready',ready);
  }
  async function updateCatalog(){
    if(!CATALOG)return;
    $('updateCatalog').disabled=true;
    setCatalogStatus('Buscando modelos nuevos…',CARS.length>54);
    try {
      const result=await CATALOG.loadOnline();
      setCatalogStatus(result.source==='oficial'?'Catálogo oficial actualizado':'Catálogo ampliado · fuente comunitaria',true);
      if(document.activeElement===$('carSearch') && $('carSearch').value.trim() && $('carSearch').value!==selectedCar?.label){showMatches($('carSearch').value);}
      if(result.added>0)toast(`Se incorporaron ${result.added} modelos al catálogo.`);
    }catch(e){
      setCatalogStatus(CARS.length>54?'Catálogo guardado · sin actualización':'54 autos sin conexión · probá Actualizar',CARS.length>54);
    }finally{$('updateCatalog').disabled=false;}
  }
  function initializeCatalog(){
    const cached=CATALOG?.cacheRead();
    if(cached){setCatalogStatus('Catálogo guardado · disponible sin conexión',true);}
    else{setCatalogStatus('54 autos incluidos · ampliando catálogo…');}
    updateCatalog();
  }
  function attach(){
    $('catalogCount').textContent=CARS.length;
    applyCar(selectedCar);renderModes();updateSavedCount();
    $('updateCatalog').addEventListener('click',updateCatalog);
    initializeCatalog();
    $('carSearch').addEventListener('input',e=>{showMatches(e.target.value);$('clearSearch').hidden=!e.target.value;});
    $('carSearch').addEventListener('focus',e=>{if(e.target.value===selectedCar?.label)e.target.select();else showMatches(e.target.value);});
    $('clearSearch').addEventListener('click',()=>{$('carSearch').value='';$('carSearch').focus();showMatches('');$('clearSearch').hidden=true;});
    $('carOptions').addEventListener('click',e=>{
      const button=e.target.closest('[data-car-id]');if(button){const car=CARS.find(c=>c.id===button.dataset.carId);if(car)applyCar(car);}
      if(e.target.closest('#useCustomFromSearch')){switchManual($('carSearch').value);$('customName').focus();}
    });
    document.addEventListener('click',e=>{if(!e.target.closest('.car-search-group'))closeSearch();});
    $('manualSwitch').addEventListener('click',toggleManual);
    $('customName').addEventListener('input',refreshSide);
    $('googleSearch').addEventListener('click',()=>{
      const name=manual?$('customName').value.trim()||$('carSearch').value.trim():$('carSearch').value.trim()||selectedCar?.label;
      const q=`${name||'Forza Horizon 6'} Forza Horizon 6 peso potencia reparto de peso setup tune`;
      window.open('https://www.google.com/search?q='+encodeURIComponent(q),'_blank','noopener,noreferrer');
      toast('Se abrió la búsqueda en Google: esta versión no extrae datos automáticamente.');
    });
    $('modeGrid').addEventListener('click',e=>{const button=e.target.closest('[data-mode]');if(button){selectedMode=button.dataset.mode;renderModes();}});
    $('bias').addEventListener('input',showBias);
    $('step1Next').addEventListener('click',()=>goStep(2));
    $('step2Back').addEventListener('click',()=>goStep(1));
    $('step2Next').addEventListener('click',()=>goStep(3));
    $('step3Back').addEventListener('click',()=>goStep(2));
    $('restart').addEventListener('click',()=>goStep(1));
    [1,2,3].forEach(i=>$('nav'+i).addEventListener('click',()=>{if(i===1 || i<=activeStep || i===2)goStep(i); else if(i===3 && activeStep===2)goStep(3);}));
    $('toggleAll').addEventListener('click',()=>{allOpen=!allOpen;document.querySelectorAll('.tune-section').forEach(d=>d.open=allOpen);$('toggleAll').textContent=allOpen?'Cerrar todas':'Abrir todas';});
    $('resultsList').addEventListener('click',e=>{const btn=e.target.closest('[data-copy-section]');if(btn){const sec=window._easyTuneSections?.[Number(btn.dataset.copySection)];if(sec)copyText(sectionText(sec));}});
    $('copyAll').addEventListener('click',()=>copyText(fullText()));
    $('saveTune').addEventListener('click',saveCurrent);
    $('downloadTune').addEventListener('click',()=>download('easytune-configuracion.txt',fullText(),'text/plain;charset=utf-8'));
    $('openSaves').addEventListener('click',showSaves);
    $('closeSaves').addEventListener('click',()=>$('savesDialog').close());
    $('dialogCloseBottom').addEventListener('click',()=>$('savesDialog').close());
    $('savedItems').addEventListener('click',e=>{
      const load=e.target.closest('[data-load]');const del=e.target.closest('[data-delete]');
      if(load){const found=saved.find(s=>s.id===load.dataset.load);if(found)loadSave(found)}
      if(del){saved=saved.filter(s=>s.id!==del.dataset.delete);writeSaved();showSavesItemsOnly();}
    });
    $('exportSaves').addEventListener('click',()=>download('easytune-guardados.json',JSON.stringify({format:'easytune-v1',exportedAt:new Date().toISOString(),saved},null,2),'application/json'));
  }
  function showSavesItemsOnly(){
    $('savedItems').innerHTML=saved.length?saved.map(s=>`<div class="saved-row"><div><strong>${safe(s.label)}</strong><small>${new Date(s.created).toLocaleDateString('es-AR')}</small></div><div class="saved-row-actions"><button type="button" data-load="${escapeAttr(s.id)}">Abrir</button><button type="button" class="delete" data-delete="${escapeAttr(s.id)}">✕</button></div></div>`).join(''):'<div class="empty-saves">No hay configuraciones guardadas.</div>';
  }
  attach();
  window.EasyTuneApp={getState:()=>({selectedMode,selectedCar:selectedCar?.label,manual,activeStep,tune}),goStep,readInput,computeAndRender};
})();
