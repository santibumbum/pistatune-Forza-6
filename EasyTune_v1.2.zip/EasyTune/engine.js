/* EasyTune: motor determinista ORIGINAL de heurísticas para puntos de partida.
 * No afirma usar un modelo físico calibrado ni encontrar el óptimo. Sin IA ni red.
 * License: MIT (código de la demo EasyTune).
 */
(function(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.EasyTuneEngine = api;
})(typeof window !== 'undefined' ? window : globalThis, function(){
  'use strict';
  const clamp = (v,min,max) => Math.max(min, Math.min(max,v));
  const round = (v,dp=0) => { const k=10**dp; return Math.round((v+Number.EPSILON)*k)/k; };
  const MODES={
    balance:{id:'balance',label:'Bueno en todo',emoji:'⚖️',short:'Equilibrio para carreras',description:'Un poco de aceleración, velocidad y agarre.',pro:'Útil para la mayoría de las carreras.',con:'No maximiza una sola cosa.',target:320,bar:0,camber:0,rate:0,downforce:0.5,pressure:0,lock:0},
    accel:{id:'accel',label:'Acelerar muchísimo',emoji:'⚡',short:'Salidas rápidas y recuperación',description:'Para priorizar 0–100 y 0–200 km/h.',pro:'Marchas más cortas y tracción al salir.',con:'La velocidad máxima puede bajar.',target:265,bar:-2,camber:0.35,rate:-0.18,downforce:0.08,pressure:-0.06,lock:7},
    speed:{id:'speed',label:'Correr más rápido',emoji:'🚀',short:'Velocidad punta',description:'Para rectas largas y autopistas.',pro:'Marchas largas y menos carga aerodinámica.',con:'Menos respuesta al acelerar y doblar.',target:385,bar:0,camber:0.40,rate:0.05,downforce:0,pressure:0.08,lock:-6},
    grip:{id:'grip',label:'Doblar mejor',emoji:'🧲',short:'Agarre en curvas',description:'Para curvas rápidas sin irte de costado.',pro:'Más control lateral y estabilidad.',con:'Puede perder velocidad punta.',target:295,bar:2,camber:-0.5,rate:0.12,downforce:0.9,pressure:-0.03,lock:-2},
    technical:{id:'technical',label:'Circuito con curvas',emoji:'🏁',short:'Curvas cerradas y frenadas',description:'Para caminos trabados donde frenás y acelerás seguido.',pro:'Agilidad y salida de curva.',con:'Menos pensado para autopistas.',target:270,bar:1,camber:-0.4,rate:0.02,downforce:0.7,pressure:-0.04,lock:0},
    drift:{id:'drift',label:'Derrapar fácil',emoji:'💨',short:'Drift controlado',description:'Para poner el auto de costado.',pro:'Facilita iniciar y mantener derrapes.',con:'No sirve para lograr el mejor tiempo de vuelta.',target:250,bar:5,camber:-0.25,rate:0.2,downforce:0,pressure:0.22,lock:32},
    offroad:{id:'offroad',label:'Tierra y saltos',emoji:'⛰️',short:'Rally y todoterreno',description:'Para caminos irregulares, grava y tierra.',pro:'Suspensión más suave y mejor contacto en baches.',con:'Peor respuesta en asfalto liso.',target:235,bar:-8,camber:0.3,rate:-0.36,downforce:0.15,pressure:-0.23,lock:9}
  };
  const PROFILES={
    track:{mass:1170,power:620,front:43,rpm:8200,radius:0.335},
    hyper:{mass:1550,power:780,front:43,rpm:8000,radius:0.345},
    super:{mass:1450,power:540,front:44,rpm:7800,radius:0.34},
    sport:{mass:1400,power:290,front:51,rpm:7000,radius:0.325},
    muscle:{mass:1770,power:480,front:54,rpm:6600,radius:0.345},
    rally:{mass:1330,power:350,front:56,rpm:7400,radius:0.325},
    hatch:{mass:1420,power:300,front:60,rpm:6800,radius:0.32},
    offroad:{mass:2130,power:390,front:55,rpm:6300,radius:0.38},
    electric:{mass:2150,power:900,front:49,rpm:14000,radius:0.35}
  };
  const COMPOUNDS={street:0.11,sport:0.03,race:0,rally:-0.12,offroad:-0.20,drift:0.17};
  const pct = v => `${Math.round(v)}% del deslizador`;
  function deriveProfile(car){
    const profile=(car && car.profile) || 'sport';
    // Preset del Sesto solo como referencia para facilitar la demo: no datos medidos in-game.
    if(car && car.make==='Lamborghini' && car.model==='Sesto Elemento')
      return {mass:1000,power:570,front:43,rpm:8500,radius:0.335};
    return {...(PROFILES[profile]||PROFILES.sport)};
  }
  function parseNumeric(raw, fallback, lower, upper) {
    const x=(typeof raw==='string')?Number(raw.replace(',','.')):Number(raw);
    return Number.isFinite(x) && x>0 ? clamp(x,lower,upper):fallback;
  }
  function resolveSpecs(input){
    const preset=deriveProfile(input.car);
    const custom={...input};
    return {
      carName: input.name || input.car?.label || 'Auto personalizado',
      profile:input.car?.profile || input.profile || 'sport',
      drive: ['AWD','RWD','FWD'].includes(input.drive) ? input.drive : (input.car?.drive || 'RWD'),
      gears:Math.round(parseNumeric(input.gears, input.car?.gears || 6, 1, 10)),
      mass:parseNumeric(custom.mass,preset.mass,450,5000),
      power:parseNumeric(custom.power,preset.power,30,2500),
      front:parseNumeric(custom.front,preset.front,28,75),
      rpm:parseNumeric(custom.rpm,preset.rpm,3000,20000),
      radius:parseNumeric(custom.radius,preset.radius,0.24,0.55),
      tire: COMPOUNDS[input.tire] === undefined ? 'sport' : input.tire,
      adjustables: input.adjustables || {suspension:true,aero:false,brakes:true,diff:true},
      ranges: input.ranges || {},
      isPreset: !input.mass && !input.power && !input.front && !input.rpm && !input.radius,
      sourceKind: input.car?'car-list + estimated specifications':'manual vehicle + estimated specifications'
    };
  }
  function scaledValue(ranges,axle,section,p){
    const l=ranges?.[section+axle+'Min'];
    const h=ranges?.[section+axle+'Max'];
    const min=Number(l),max=Number(h);
    if(l!=='' && h!=='' && l!==undefined && h!==undefined && Number.isFinite(min) && Number.isFinite(max) && max>min) {
      return {value:round(min+(max-min)*(p/100),1), unit:section==='spring'?'kgf/mm':'cm', precise:false, note:'Interpolación entre los límites que ingresaste (no telemetría).'};
    }
    return {value:pct(p),unit:'',precise:false,note:'Sin límites del juego; copiá la posición aproximada del deslizador.'};
  }
  function calculate(input){
    const s=resolveSpecs(input);
    const m=MODES[input.mode] || MODES.balance;
    const bias=clamp(Number(input.bias)||0,-5,5);
    // Son reglas plausibles y repetibles, no un modelo de la física propietaria FH6.
    const frontWeight=s.front/100;
    const extraPower=clamp((s.power/s.mass-0.32)*2,-0.3,0.55);
    const pF=round(clamp(1.95+(frontWeight-.5)*.36+m.pressure+COMPOUNDS[s.tire]+extraPower*.06,1.55,2.65),2);
    const pR=round(clamp(1.93-(frontWeight-.5)*.22+m.pressure+COMPOUNDS[s.tire]+extraPower*.05+(m.id==='drift'?.18:0),1.55,2.75),2);
    const n=s.gears;
    const gearRatios=[];
    let ratioFirst= (m.id==='drift'?3.38 : m.id==='offroad'?3.36 : m.id==='accel'?2.98 : m.id==='speed'?2.85:3.12);
    if(s.drive==='RWD' && m.id==='accel') ratioFirst-=0.24;
    if(s.drive==='FWD' && m.id==='accel') ratioFirst-=0.32;
    const ratioLast=n===1?1:(n>=8?0.68:n===7?0.76:n===6?0.82:n===5?0.92:1.05);
    for(let i=0;i<n;i++){
      const t=n===1?1:i/(n-1);
      gearRatios.push(round(ratioFirst*Math.pow(ratioLast/ratioFirst,t),2));
    }
    // Top speed "teórico por RPM" usado SOLO para elegir final drive como punto inicial.
    // No contempla arrastre, grip, pérdidas de transmisión o curva de potencia.
    const targetSpeed=clamp(m.target * Math.pow(s.power/600,.10) * Math.pow(1400/s.mass,.06),130,440);
    const topRatio=gearRatios[n-1];
    const finalDrive=round(clamp(s.rpm*2*Math.PI*s.radius*60/(1000*targetSpeed*topRatio),2.2,6),2);
    const rpmTop=round(s.rpm*2*Math.PI*s.radius*60/(1000*finalDrive*topRatio),0);
    const isRally=m.id==='offroad';
    const isDrift=m.id==='drift';
    const camF=round(clamp((-1.20+m.camber)+(isRally?.2:0)+(isDrift?-.7:0),-3.5,0),1);
    const camR=round(clamp((-0.90+m.camber)+(isRally?.15:0)+(isDrift?-.45:0),-3.5,0),1);
    const toeF=isDrift?0.2:0;
    const toeR=isDrift?-0.1:0;
    const caster=isDrift?7: isRally?5.8:6.1;
    // 1–65 representan unidades arbitrarias del juego.
    const barFront=round(clamp(28+(s.front-50)*.43+m.bar-(bias*1.25)-(isDrift?2:0),1,65),1);
    const barRear=round(clamp(29-(s.front-50)*.24+m.bar+(bias*1.35)+(isDrift?8:0),1,65),1);
    const baseSpring=clamp(57+(s.mass-1350)*.013 + m.rate*65,12,87);
    const springFP=round(clamp(baseSpring+(s.front-50)*1.05+bias*.7,8,96));
    const springRP=round(clamp(baseSpring-(s.front-50)*.80-bias*.7+(s.drive==='RWD'?3:0),8,96));
    const heightBase=isRally?78:isDrift?38: m.id==='speed'?14: m.id==='grip'?22: m.id==='accel'?26:30;
    const heightFP=round(clamp(heightBase+(s.front-50)*.24,5,95));
    const heightRP=round(clamp(heightBase-(s.front-50)*.18+(m.id==='accel'?4:0),5,95));
    const reboundF=round(clamp(7.8 + (springFP-55)*.045 + (isRally?-1.0:0),3,15),1);
    const reboundR=round(clamp(8.2 + (springRP-55)*.045 + (isRally?-1.0:0),3,15),1);
    const bumpF=round(clamp(reboundF*(isRally?.55:.59),1,15),1);
    const bumpR=round(clamp(reboundR*(isRally?.55:.59),1,15),1);
    const frontAeroPct=round(clamp(15 + m.downforce*68 - bias*1.2,0,100));
    const rearAeroPct=round(clamp(25 + m.downforce*62 + bias*1.5,0,100));
    const brakeBalance=round(clamp(50+(s.front-50)*.2-bias*.35+(isDrift?-3:0),43,59));
    const brakePressure=isRally?90:100;
    const diffA=s.drive==='AWD' ? {fAccel:round(clamp(20+m.lock*.35,5,100)),fDecel:isRally?16:5,
     rAccel:round(clamp((isDrift?80:58)+m.lock,5,100)),rDecel:isDrift?26:12,
     center:round(clamp((isDrift?87:isRally?58:70)+bias*.75,50,100))} : {
      accel:round(clamp((isDrift?86:s.drive==='FWD'?37:55)+m.lock,5,100)),
      decel:isDrift?20:isRally?15: s.drive==='FWD'?7:12
     };
    const transmission = {final:finalDrive,ratios:gearRatios,topSpeedRpm:rpmTop,goalTarget:round(targetSpeed,0)};
    const ranges=s.ranges;
    return {
      specs:s,mode:m,bias,
      tires:{front:pF,rear:pR},transmission,
      align:{camF,camR,toeF,toeR,caster},
      bars:{front:barFront,rear:barRear},
      springs:{front:scaledValue(ranges,'F','spring',springFP),rear:scaledValue(ranges,'R','spring',springRP),
        heightF:scaledValue(ranges,'F','height',heightFP),heightR:scaledValue(ranges,'R','height',heightRP),
        springFP,springRP,heightFP,heightRP},
      damping:{reboundF,reboundR,bumpF,bumpR},
      aero:{front:pct(frontAeroPct),rear:pct(rearAeroPct),frontPct:frontAeroPct,rearPct:rearAeroPct},
      brakes:{balance:brakeBalance,pressure:brakePressure},diff:diffA,
      guidance: m.id==='drift' && s.drive==='FWD' ? 'Drift con tracción delantera es más limitado; el algoritmo no puede cambiar la tracción.' : '',
      timestamp: new Date().toISOString()
    };
  }
  return {MODES, PROFILES, clamp, resolveSpecs,calculate};
});
