# EasyTune — prototipo 1.2 (sin IA)

Una calculadora muy sencilla para **Forza Horizon 6**, en español, sin cuenta, sin IA, sin anuncios y sin backend.

## Cómo abrirla

1. Descargá y descomprimí `EasyTune.zip`.
2. Entrá a la carpeta `EasyTune`.
3. Hacé doble clic en **`index.html`**: funciona en Chrome, Edge, Brave o Firefox, también sin conexión. Para descargar el catálogo ampliado por primera vez hace falta conexión a Internet.

> Importante: los seis archivos `index.html`, `styles.css`, `catalog.js`, `catalog-loader.js`, `engine.js` y `app.js` deben permanecer juntos.

## Qué funciona ahora

- **54 autos preinstalados** para abrir sin conexión, más un **catálogo ampliado de cientos de vehículos** que la app intenta cargar automáticamente desde fuentes públicas al abrirla online.
- Se intenta primero el listado oficial de Forza; si su política CORS impide leerlo desde un archivo local, se usa una **lista comunitaria de GitHub** como alternativa. Los modelos se cachean en el navegador y quedan disponibles para usos posteriores sin conexión, mientras no se borren los datos de ese sitio/archivo. No se garantiza que incluya cada auto agregado en los últimos días.
- Botón **↻ Actualizar** y estado de conexión/catálogo visibles; no requiere ninguna API paga.
- **Autos personalizados** aunque el modelo no figure en el catálogo: simplemente escribí el nombre y continuá. Se muestran como estimaciones por tipo de vehículo.
- **Buscador corregido**: campo de texto totalmente visible, sugerencias **debajo del input** y dentro del flujo de la página (sin superposición), selección del nombre actual al hacer foco, y botón «Usar este nombre».
- Enlace directo de búsqueda en Google (sin automatización ni scraping).
- **Siete modos de tuneo** fáciles de entender.
- Cambiar tracción, marchas, compuesto de neumáticos y modificaciones.
- Calculador original determinista para neumáticos, relaciones de marcha, alineación, barras, muelles/altura, amortiguación, aero, frenos y diferencial.
- Mostrar muelles/altura como **% del deslizador** si no conocemos los límites del auto. Con los límites proporcionados por el jugador calcula los números interpolados.
- Copiar sección / copiar todo, descargar en TXT y guardar localmente en el navegador. Exportar guardados JSON.
- Diseño adaptable a celular y computadora. Los cálculos funcionan en forma local; la **actualización opcional del catálogo** consulta una lista externa.

## Importante sobre la precisión

**No es un motor calibrado con la física real de Forza Horizon 6 y no encuentra el óptimo**. Genera estimaciones iniciales basadas en reglas generales y características elegidas por el usuario. La lista oficial confirma nombres de vehículos, categoría y clase de serie, pero NO contiene los valores de potencia/peso que necesita el cálculo; esos se **estiman por categoría** si no se ingresan.

- El límite de velocidad mostrado en el apartado transmisión es un **límite geométrico por RPM**; no es la velocidad punta real.
- Muelles, alturas y aerodinámica dependen de los topes disponibles en cada auto/parte. Por eso usamos porcentaje si faltan rangos.
- Las piezas regulables y las mejoras pueden modificar qué controles aparecen en el juego.
- No requiere ni usa modelos de IA, API ni servicio pago.
- El botón **Google** solamente abre una búsqueda: leer y verificar automáticamente datos desde Google necesitaría un servicio permitido, y no está implementado en esta versión.

## Código, publicación y próximos pasos

Es HTML, CSS y JavaScript sin frameworks ni compilación. Para publicarla en GitHub Pages, subí los cinco archivos a la raíz de un repositorio y activá Settings > Pages > Deploy from branch.

Próximos hitos: incluir también un archivo offline con todo el catálogo oficial, si se obtiene una fuente autorizada para su distribución; validar el algoritmo con cronometrajes en juego; telemetría con un receptor UDP local (FH6 ofrece Data Out); mejorar la entrada de modificaciones y sugerencias de ajustes por síntomas; pruebas de usabilidad con jugadores principiantes.

## Fuentes consultadas

- Catálogo oficial FH6 (noviembre 2026): https://forza.net/fh6cars
- Documentación oficial Data Out: https://support.forza.net/hc/en-us/articles/51744149102611-Forza-Horizon-6-Data-Out-Documentation
- Lista comunitaria usada como alternativa de actualización: https://github.com/StevenGPL/Forza-Horizon-6-Online-Car-List
- Referencia de enfoque heurístico: https://github.com/smadam813/fh6-tuning-calculator (no se reutiliza su código en este prototipo)

## Licencia

Código original del prototipo: MIT. Marca de ejemplo "EasyTune"; no afiliado a Xbox, Turn 10 Studios ni Playground Games.

## Cambios de la versión 1.2

- El desplegable ya no se ubica en posición absoluta: ahora aparece debajo del buscador, dejando siempre el texto escrito a la vista.
- Catálogo online ampliado (fuente oficial cuando CORS lo permite, lista comunitaria como alternativa). Caché local de resultados y botón de actualización.
- Los autos importados sin datos de tracción o marchas muestran una aclaración: estos valores son supuestos y el usuario puede corregirlos.
- Compatibilidad con configuraciones guardadas anteriormente.

## Cambios de la versión 1.1

- Buscador con letras oscuras sobre fondo blanco, cursor y texto seleccionados claramente visibles.
- Al buscar un auto no registrado, aparece un botón para usar exactamente el nombre escrito.
- El resumen ya no muestra el modelo anterior mientras el usuario escribe otro.
- En el siguiente paso, los datos faltantes siguen siendo estimaciones; no se atribuyen características de otro modelo al auto recién escrito.
