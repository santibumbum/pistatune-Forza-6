/* EasyTune catalog adapter. Downloads only published car *names*, classes and types.
 * No AI, no Google scraping, no mechanical specifications inferred from a webpage.
 * Local base catalogue always works offline. A successful sync is cached for offline use.
 */
(function (root) {
  'use strict';
  const BASE = root.EASYTUNE_CARS || [];
  const CACHE_KEY = 'easytune.fh6.catalog.2026.v2';
  const OFFICIAL = 'https://forza.net/fh6cars';
  const COMMUNITY = 'https://raw.githubusercontent.com/StevenGPL/Forza-Horizon-6-Online-Car-List/main/Cars.json';
  const MIRROR = 'https://cdn.jsdelivr.net/gh/StevenGPL/Forza-Horizon-6-Online-Car-List@main/Cars.json';
  const clean = x => String(x == null ? '' : x).replace(/\s+/g, ' ').trim();
  const normalize = x => clean(x).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const key = c => [c.make, c.model, c.year].map(normalize).join('|').replace(/[\s\u2010-\u2015\-]/g,'');
  const inferProfile = category => {
    const c=normalize(category);
    if(/rally|retro rally|offroad race/.test(c))return 'rally';
    if(/extreme track|track toys|racer|time attack/.test(c))return 'track';
    if(/hypercar/.test(c))return 'hyper';
    if(/supercar|super cars|super gt/.test(c))return 'super';
    if(/muscle|rod|custom/.test(c))return 'muscle';
    if(/hatch|domestic|cult car/.test(c))return 'hatch';
    if(/pickup|offroad|off-road|bugg|suv|utility|truck|utv/.test(c))return 'offroad';
    return 'sport';
  };
  const guessDrive = (p,cat) => {
    if (p === 'offroad' || p === 'rally') return 'AWD';
    if (p === 'hatch') return 'FWD';
    return 'RWD';
  };
  const guessGears = (year,cat) => /electri/i.test(cat)?1:year>=2014?7:year>=2000?6:year>=1980?5:4;
  function fromFields(make, model, year, pi, category, source) {
    make=clean(make);model=clean(model);year=Number(year);pi=clean(pi);category=clean(category);
    if (!make || !model || !Number.isInteger(year) || year<1880 || year>2700 || !category) return null;
    if (normalize(model).startsWith(normalize(make)+' ')) model=model.slice(make.length).trim();
    const performance=/^(\d{1,4})\s+(D|C|B|A|S1|S2|R)$/i.exec(pi);
    if(performance)pi=performance[2].toUpperCase()+' '+performance[1];
    const profile=inferProfile(category);
    const item={make,model,year,pi:pi||'Clase por confirmar',category,profile,
      drive:guessDrive(profile,category),gears:guessGears(year,category),catalogSource:source,
      isEstimatedDrivetrain:true};
    item.id='fh6-'+key(item).replace(/[^a-z0-9|]/gi,'').replace(/\|/g,'-');
    item.label=`${make} ${model} · ${year}`;
    return item;
  }
  function parseOfficial(html) {
    const doc=new DOMParser().parseFromString(html,'text/html');
    const result=[];
    for(const tr of doc.querySelectorAll('table tbody tr, table tr')) {
      const cells=Array.from(tr.querySelectorAll('td')).map(td=>clean(td.textContent));
      if(cells.length<4)continue;
      const [make, fullName,category,pi]=cells;
      const m=/^(\d{4})\s+(.+)$/.exec(fullName);
      if(!m)continue;
      result.push(fromFields(make,m[2],m[1],pi,category,'oficial'));
    }
    return result.filter(Boolean);
  }
  function parseCommunity(json) {
    const data=Array.isArray(json)?json:Array.isArray(json.cars)?json.cars:[];
    return data.map(x=>{
      const make=clean(String(x.brand||x.make||'').split('\n')[0]);
      const year=Number(x.year || (String(x.name||'').match(/(?:19|20|25)\d{2}$/)||[])[0]);
      const model=clean(x.name||x.model||'').replace(new RegExp('\\s+'+year+'$'), '');
      return fromFields(make,model,year,x.initial_score||x.pi||'',x.car_type_en||x.category||'Deportivo','comunitario');
    }).filter(Boolean);
  }
  function merge(incoming) {
    const existing=new Map(BASE.map(c=>[key(c),c]));
    let added=0;
    for(const car of incoming){
      const k=key(car);
      if(existing.has(k)) {
        const old=existing.get(k);
        if(old.catalogSource==='comunitario' && car.catalogSource==='oficial') {
          old.pi=car.pi;old.category=car.category;old.catalogSource='oficial';
        }
        continue;
      }
      existing.set(k,car);BASE.push(car);added++;
    }
    BASE.sort((a,b)=>a.make.localeCompare(b.make,'es') || a.model.localeCompare(b.model,'es') || a.year-b.year);
    return added;
  }
  function cacheRead(){
    try {
      const cached=JSON.parse(localStorage.getItem(CACHE_KEY)||'null');
      if(!cached || !Array.isArray(cached.cars) || cached.cars.length<100)return null;
      // Untrusted cache must not overwrite app behavior.
      const records=cached.cars.slice(0,1500).map(c=>fromFields(c.make,c.model,c.year,c.pi,c.category,c.catalogSource||'comunitario')).filter(Boolean);
      if(records.length<100)return null;
      merge(records);
      return {count:BASE.length,source:cached.source||'caché',date:cached.date};
    }catch{return null;}
  }
  async function getWithTimeout(url,expect){
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),7500);
    try{
      const res=await fetch(url,{mode:'cors',signal:controller.signal,cache:'no-cache'});
      if(!res.ok)throw new Error('HTTP '+res.status);
      return expect==='html'?await res.text():await res.json();
    }finally{clearTimeout(timer);}
  }
  async function loadOnline() {
    let source='oficial',data=[];
    try { data=parseOfficial(await getWithTimeout(OFFICIAL,'html')); } catch(e) { /* CORS del sitio oficial puede impedir leer su tabla */ }
    if(data.length<500) {
      source='comunitario';
      for(const url of [COMMUNITY,MIRROR]) {
        try { data=parseCommunity(await getWithTimeout(url,'json')); if(data.length>=500)break; } catch(e) { data=[]; }
      }
    }
    if(data.length<500)throw Error('No se pudo consultar una lista suficientemente completa.');
    const added=merge(data);
    try { localStorage.setItem(CACHE_KEY,JSON.stringify({date:new Date().toISOString(),source,
      cars:data.map(({make,model,year,pi,category,catalogSource})=>({make,model,year,pi,category,catalogSource}))}));}catch{};
    return {added,count:BASE.length,source,date:new Date().toISOString()};
  }
  root.EasyTuneCatalog = { cacheRead,loadOnline,parseOfficial,parseCommunity,merge,inferProfile,OFFICIAL,COMMUNITY };
})(window);
